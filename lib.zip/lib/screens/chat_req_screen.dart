// lib/screens/chat_requests_screen.dart
import 'package:flutter/material.dart';
import 'package:skillsync/models/chat_request_model.dart';
import 'package:skillsync/screens/chat_screen.dart';

class ChatRequestsScreen extends StatefulWidget {
  @override
  State<ChatRequestsScreen> createState() => _ChatRequestsScreenState();
}

class _ChatRequestsScreenState extends State<ChatRequestsScreen> {
  // Mock incoming requests
  final List<ChatRequest> _requests = [
    ChatRequest(
      id: '1',
      fromUserId: 'user1',
      fromUserName: 'Alex Kumar',
      fromUserAvatar: '',
      toUserId: 'me',
      subject: 'Help with React Hooks',
      message:
          'Hi! I\'m a beginner with React and would love to learn about hooks. I have basic JavaScript knowledge.',
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      status: ChatRequestStatus.pending,
      skill: 'React',
    ),
    ChatRequest(
      id: '2',
      fromUserId: 'user2',
      fromUserName: 'Maria Santos',
      fromUserAvatar: '',
      toUserId: 'me',
      subject: 'Flutter State Management',
      message:
          'Hello! I\'m building my first Flutter app and need help with state management. Can you help?',
      timestamp: DateTime.now().subtract(const Duration(hours: 5)),
      status: ChatRequestStatus.pending,
      skill: 'Flutter',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final pendingRequests =
        _requests.where((r) => r.status == ChatRequestStatus.pending).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Learning Requests'),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body:
          pendingRequests.isEmpty
              ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.inbox, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text(
                      'No pending requests',
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  ],
                ),
              )
              : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: pendingRequests.length,
                itemBuilder: (context, index) {
                  final request = pendingRequests[index];
                  return _buildRequestCard(request);
                },
              ),
    );
  }

  Widget _buildRequestCard(ChatRequest request) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: Text(
                    request.fromUserName[0],
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        request.fromUserName,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        _formatTime(request.timestamp),
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                if (request.skill != null)
                  Chip(
                    label: Text(
                      request.skill!,
                      style: const TextStyle(fontSize: 12),
                    ),
                    backgroundColor: Theme.of(
                      context,
                    ).colorScheme.primary.withOpacity(0.1),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              request.subject,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Text(request.message, style: TextStyle(color: Colors.grey[700])),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _declineRequest(request),
                    child: const Text('Decline'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _acceptRequest(request),
                    child: const Text('Accept'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _acceptRequest(ChatRequest request) {
    setState(() {
      request = ChatRequest(
        id: request.id,
        fromUserId: request.fromUserId,
        fromUserName: request.fromUserName,
        fromUserAvatar: request.fromUserAvatar,
        toUserId: request.toUserId,
        subject: request.subject,
        message: request.message,
        timestamp: request.timestamp,
        status: ChatRequestStatus.accepted,
        skill: request.skill,
      );
    });

    // Navigate to chat screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => ChatScreen(
              chatRoomId: 'chat_${request.id}',
              otherUserName: request.fromUserName,
            ),
      ),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Accepted request from ${request.fromUserName}')),
    );
  }

  void _declineRequest(ChatRequest request) {
    setState(() {
      _requests.removeWhere((r) => r.id == request.id);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Declined request from ${request.fromUserName}')),
    );
  }
}
