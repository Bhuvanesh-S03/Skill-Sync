import 'package:flutter/material.dart';
import 'package:skillsync/models/chat_request_model.dart';
import 'package:skillsync/screens/send_request_screen.dart';

class DiscoverUsersScreen extends StatefulWidget {
  @override
  State<DiscoverUsersScreen> createState() => _DiscoverUsersScreenState();
}

class _DiscoverUsersScreenState extends State<DiscoverUsersScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedSkill = 'All';

  // Mock users data
  final List<UserProfile> _users = [
    UserProfile(
      id: '1',
      name: 'Sarah Chen',
      avatar: '',
      bio: 'Frontend developer with 5 years React experience. Love teaching!',
      skills: ['React', 'JavaScript', 'CSS', 'HTML'],
      rating: 4.8,
      totalSessions: 23,
      isOnline: true,
    ),
    UserProfile(
      id: '2',
      name: 'Mike Johnson',
      avatar: '',
      bio:
          'Full-stack developer. Passionate about helping others learn coding.',
      skills: ['Python', 'Django', 'PostgreSQL', 'AWS'],
      rating: 4.9,
      totalSessions: 45,
      isOnline: false,
    ),
    UserProfile(
      id: '3',
      name: 'Emma Davis',
      avatar: '',
      bio: 'UI/UX Designer & Flutter developer. Happy to share knowledge!',
      skills: ['Flutter', 'Dart', 'Figma', 'UI Design'],
      rating: 4.7,
      totalSessions: 18,
      isOnline: true,
    ),
  ];

  List<UserProfile> get _filteredUsers {
    var filtered = _users;

    if (_selectedSkill != 'All') {
      filtered =
          filtered
              .where((user) => user.skills.contains(_selectedSkill))
              .toList();
    }

    final query = _searchController.text.toLowerCase();
    if (query.isNotEmpty) {
      filtered =
          filtered
              .where(
                (user) =>
                    user.name.toLowerCase().contains(query) ||
                    user.skills.any(
                      (skill) => skill.toLowerCase().contains(query),
                    ),
              )
              .toList();
    }

    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Find Mentors'),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: Column(
        children: [
          // Search and Filter Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey[50],
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by name or skill...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildSkillFilter('All'),
                      _buildSkillFilter('React'),
                      _buildSkillFilter('Python'),
                      _buildSkillFilter('Flutter'),
                      _buildSkillFilter('JavaScript'),
                      _buildSkillFilter('UI Design'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Users List
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredUsers.length,
              itemBuilder: (context, index) {
                final user = _filteredUsers[index];
                return _buildUserCard(user);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkillFilter(String skill) {
    final isSelected = _selectedSkill == skill;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(skill),
        selected: isSelected,
        onSelected: (_) => setState(() => _selectedSkill = skill),
        backgroundColor: Colors.white,
        selectedColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
      ),
    );
  }

  Widget _buildUserCard(UserProfile user) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 25,
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: Text(
                        user.name[0],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (user.isOnline)
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          width: 16,
                          height: 16,
                          decoration: BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber, size: 16),
                          Text(
                            ' ${user.rating} (${user.totalSessions} sessions)',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.chat_bubble_outline),
                  onPressed: () => _sendChatRequest(user),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(user.bio, style: TextStyle(color: Colors.grey[600])),
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children:
                  user.skills
                      .map(
                        (skill) => Chip(
                          label: Text(
                            skill,
                            style: const TextStyle(fontSize: 12),
                          ),
                          backgroundColor: Theme.of(
                            context,
                          ).colorScheme.primary.withOpacity(0.1),
                        ),
                      )
                      .toList(),
            ),
          ],
        ),
      ),
    );
  }

  void _sendChatRequest(UserProfile user) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SendRequestScreen(user: user)),
    );
  }
}
