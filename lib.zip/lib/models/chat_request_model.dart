// lib/models/chat_request_models.dart
class ChatRequest {
  final String id;
  final String fromUserId;
  final String fromUserName;
  final String fromUserAvatar;
  final String toUserId;
  final String subject;
  final String message;
  final DateTime timestamp;
  final ChatRequestStatus status;
  final String? skill; // What they want to learn

  ChatRequest({
    required this.id,
    required this.fromUserId,
    required this.fromUserName,
    required this.fromUserAvatar,
    required this.toUserId,
    required this.subject,
    required this.message,
    required this.timestamp,
    required this.status,
    this.skill,
  });
}

enum ChatRequestStatus { pending, accepted, declined, expired }

class UserProfile {
  final String id;
  final String name;
  final String avatar;
  final String bio;
  final List<String> skills;
  final double rating;
  final int totalSessions;
  final bool isOnline;

  UserProfile({
    required this.id,
    required this.name,
    required this.avatar,
    required this.bio,
    required this.skills,
    required this.rating,
    required this.totalSessions,
    required this.isOnline,
  });
}
